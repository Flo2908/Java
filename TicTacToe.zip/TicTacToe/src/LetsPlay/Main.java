package LetsPlay;

import javax.imageio.ImageReader;

public class Main {

	public static void main(String[] args) {
		new Gui();
		new ImageLoader();
	}

}
