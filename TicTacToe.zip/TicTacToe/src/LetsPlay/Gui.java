package LetsPlay;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;

public class Gui {

	JFrame jF;
	Draw draw;

	static JButton btn[] = new JButton[9];
	static int[] state = new int[9];
	static int player = 0;
	static int winner = 0;
	JButton btnReset;

	public Gui() {

		jF = new JFrame();
		jF.setSize(800, 600);
		jF.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jF.setLocationRelativeTo(null);
		jF.setResizable(false);
		jF.setTitle("TicTacToe");

		for (int i = 0; i < btn.length; i++) {
			btn[i] = new JButton();
			btn[i].setVisible(true);
			btn[i].addActionListener(new ActionHandler());
			btn[i].setFocusPainted(false);
			btn[i].setContentAreaFilled(false);
			btn[i].setBorder(null);

			jF.add(btn[i]);
		}

		ButtonPlace.place();

		btnReset = new JButton("Reset");
		btnReset.setBounds(600, 500, 100, 40);
		btnReset.setBackground(Color.GREEN);
		btnReset.setForeground(Color.WHITE);
		btnReset.setVisible(true);
		btnReset.setFocusPainted(false);
		btnReset.addActionListener(new ActionListener() {

			@Override
			public void actionPerformed(ActionEvent e) {
				Funktion.reset();

			}
		});
		
		jF.add(btnReset);

		draw = new Draw();
		draw.setBounds(0, 0, 600, 800);
		draw.setVisible(true);
		jF.add(draw);
		jF.setVisible(true);
		
	}

}
