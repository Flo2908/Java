package LetsPlay;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;

public class ActionHandler implements ActionListener {

	public ActionHandler() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if(Gui.winner == 0) {
			
			for (int i = 0; i < Gui.btn.length; i++) {

				if (e.getSource() == Gui.btn[i]) {

					if (Gui.state[i] == 0 && Gui.player == 0) {

						Gui.state[i] = 1;
						Gui.player = 1;

					} else if (Gui.state[i] == 0 && Gui.player == 1) {

						Gui.state[i] = 2;
						Gui.player = 0;
					}
				}
			}
		}
	}
}
