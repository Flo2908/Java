package programme;

public class BedingteAnweisungDemo {
	public static void main(String[] args) {

		int i = 10;
		
		if (i > 0) {
			i--;
			System.out.println(i);
		}else {
			i++;
			System.out.println(i);
		}
	}
}
