package programme;

public class HelloWorld {
	// main Methode (Klassen Methode)
		public static void main (String[] args) {
			System.out.println("Hallo");		
			
		} 
		
}
