package programme;

public class operatorenDemo {
	public static void main(String[] args) {

		// Aritmetische Operatoren;
		
		System.out.println("Tedst" + (5 +5.5));
		System.out.println("Tedst" + 5 +5.5);
		System.out.println(5+ 5.5+ "tasert");
		
		System.out.println(-50 - 25);
		
		// Inkremenet Dekrement	 (++) (--)
		int a = 5;
		System.out.println(a);
		a++;
		System.out.println(a);
		a--;
		System.out.println(a);
		System.out.println(--a);
		System.out.println(++a);
	}
}
