package Uebungen;

public class Quersumme {

}
