package Interfaces;

import java.util.Iterator;

public interface Verkaeuflich extends Iterator<Object>{

	public abstract int getPreis();
	
}
