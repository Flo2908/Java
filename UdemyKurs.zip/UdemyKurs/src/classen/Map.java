package classen;

import Interfaces.Mapping;

public class Map<K,V> implements Mapping<K,V> {

	@Override
	public void put(K key, V value) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public V get(K key) {
		// TODO Auto-generated method stub
		return null;
	}

}
