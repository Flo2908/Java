package classen;

public class LKW extends Fahrzeug{

	public LKW(String derHersteller, int dieLeistung, int preis) {
		super(derHersteller, dieLeistung, preis);
		
	}
	public LKW(String derHersteller) {
		super(derHersteller);
	}
	@Override
	public void chrashTest() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}

}
