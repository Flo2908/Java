package classen;

import java.util.ArrayList;
import java.util.Iterator;

import Interfaces.Verkaeuflich;

public class FahrzeugListe<T extends Verkaeuflich> implements Iterable<T> {

	private Object[] array;
	private int nextFreeSlot = 0;

	
	public FahrzeugListe(int capacity) {
		Object[]teste = new ArrayList<T>(capacity).toArray();
		array = teste;
	}

	public void add(T o) {
		if (nextFreeSlot == array.length) {
			throw new IllegalStateException("Liste ist voll");
		}
		array[nextFreeSlot] = o;
		nextFreeSlot++;
	}

	public T get(int index) {
		if (index > this.getCapacity() || index < 0) {
			throw new ArrayIndexOutOfBoundsException("auserhalb des Array bereiches");
		}
		return(T)array[index];
	}

	public int getCapacity() {
		
		return array.length;
	}

	public int getElementCount() {
		return nextFreeSlot;
	}
//	public int berechenSumme() {
//		int summe = 0;
//		array = (T)array;
//		for(T t : (T)array) {
//			summe += t.getPreis();
//		}
//		return summe;
//	}

	@Override
	public Iterator<T> iterator() {
		// TODO Auto-generated method stub
		return null;
	}

}
