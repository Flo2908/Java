package classen;

public class Motorrad extends Fahrzeug{

	public Motorrad(String hersteller) {
		super(hersteller);
		
	}
	public Motorrad(String derHersteller, int dieLeistung, int preis) {
		super(derHersteller, dieLeistung, preis);
		
	}
	@Override
	public void chrashTest() {
		// TODO Auto-generated method stub
		
	}
	@Override
	public boolean hasNext() {
		// TODO Auto-generated method stub
		return false;
	}
	@Override
	public Object next() {
		// TODO Auto-generated method stub
		return null;
	}
}
