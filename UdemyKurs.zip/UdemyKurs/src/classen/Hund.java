package classen;

public abstract class Hund {

}
