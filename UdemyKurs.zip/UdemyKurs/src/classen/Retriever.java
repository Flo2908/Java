package classen;

public class Retriever extends Hund {

}
